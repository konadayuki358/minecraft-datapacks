# 手動確認用: /function stalker:status
scoreboard players operation #life_display st_data = #life_x10 st_data
scoreboard players operation #life_display st_data /= #ten st_cfg
scoreboard players operation #stun_display st_data = #stun_x10 st_data
scoreboard players operation #stun_display st_data /= #ten st_cfg
scoreboard players operation #stun_seconds st_data = #stun_ticks st_data
scoreboard players add #stun_seconds st_data 19
scoreboard players operation #stun_seconds st_data /= #twenty st_cfg

tellraw @s [{text:'[ストーカーデータパック] ',color:'dark_red',bold:true},{text:'累計被ダメージ: ',color:'gray'},{score:{name:'#life_display',objective:'st_data'}},{text:' / スタン蓄積: ',color:'gray'},{score:{name:'#stun_display',objective:'st_data'}},{text:'/',color:'dark_gray'},{score:{name:'#threshold_display',objective:'st_data'}},{text:' / スタン残り: ',color:'gray'},{score:{name:'#stun_seconds',objective:'st_data'}},{text:'秒',color:'gray'}]
