# 簡易安全判定
# ・足元と頭位置が replaceable
# ・1ブロック下は replaceable ではない（奈落・水面・溶岩面を避ける）
# ・炎、溶岩、粉雪の中ではない
# ・危険な床を避ける
execute if score #placed st_data matches 0 if block ~ ~ ~ #minecraft:replaceable if block ~ ~1 ~ #minecraft:replaceable unless block ~ ~-1 ~ #minecraft:replaceable unless block ~ ~ ~ minecraft:lava unless block ~ ~1 ~ minecraft:lava unless block ~ ~ ~ minecraft:fire unless block ~ ~1 ~ minecraft:fire unless block ~ ~ ~ minecraft:soul_fire unless block ~ ~1 ~ minecraft:soul_fire unless block ~ ~ ~ minecraft:powder_snow unless block ~ ~1 ~ minecraft:powder_snow unless block ~ ~-1 ~ minecraft:magma_block unless block ~ ~-1 ~ minecraft:campfire unless block ~ ~-1 ~ minecraft:soul_campfire unless block ~ ~-1 ~ minecraft:cactus unless block ~ ~-1 ~ minecraft:pointed_dripstone run function stalker:spawn/summon_here
