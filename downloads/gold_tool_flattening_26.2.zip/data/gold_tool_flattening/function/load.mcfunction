# gold_tool_flattening
# Minecraft Java Edition 26.2
# データパック読み込み時に1回だけ表示します。

tellraw @a {text:"[gold_tool_flattening] Loaded for Minecraft Java Edition 26.2",color:"green"}
