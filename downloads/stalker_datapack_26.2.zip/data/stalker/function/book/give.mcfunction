# プレイヤーへv8説明本を1冊だけ渡し、ホームランバットのレシピを解禁する。
# Java 1.21.5以降の written_book_content / SNBT 形式を使用。
give @s minecraft:written_book[minecraft:written_book_content={title:"ストーカーデータパック",author:"ストーカーデータパック",pages:["ストーカーデータパック\n\n数分後、不死身の『ストーカー』が出現。\n逃げても、洞窟でも、別ディメンションでも追ってきます。\n\n手にはクッキー。でも殴ります。","100ダメージで約5秒スタン。\n炎・落下・ゴーレムなど、実際に受けたダメージも加算。\n\n近くでは累計被ダメージとスタン蓄積を表示。","ホームランバット\n\n棒9本を作業台の3×3すべてに並べて作成。\n\nノックバックLv10の光る棒です。\n吹き飛ばして逃げよう！"]}] 1
recipe give @s stalker:home_run_bat
scoreboard players set @s st_book 2
