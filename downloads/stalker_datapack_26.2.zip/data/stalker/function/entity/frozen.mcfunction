# スタン中は完全停止
# 毎tick速度を消し、AIと重力を止める。
data merge entity @s {NoAI:1b,NoGravity:1b,Motion:[0.0d,0.0d,0.0d]}
