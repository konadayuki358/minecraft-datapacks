# ==========================================
# ストーカー本人が実際に失ったHP量を計測
# ==========================================
# Healthをx10で読み、1024.0との差分を取る。
# 誰が攻撃したかではなく「実際にストーカーのHPが減った量」を集計する。

execute store result score @s st_hp run data get entity @s Health 10
scoreboard players operation @s st_dmg = #max_hp_x10 st_cfg
scoreboard players operation @s st_dmg -= @s st_hp

execute if score @s st_dmg matches 1.. run scoreboard players operation #life_x10 st_data += @s st_dmg
execute if score @s st_dmg matches 1.. run scoreboard players operation #stun_x10 st_data += @s st_dmg

# 計測後に最大HPへ戻す。
# 最大HP自体は召喚時 attributes と init の /attribute の両方で1024に固定している。
data modify entity @s Health set value 1024.0f

# スタン判定
execute if score #stun_ticks st_data matches 0 if score #stun_x10 st_data >= #stun_threshold_x10 st_cfg run function stalker:stun/start
