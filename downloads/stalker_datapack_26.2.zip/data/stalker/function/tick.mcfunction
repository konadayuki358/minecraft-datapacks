# ストーカーデータパック / tick

# このtickでのワープ要求を初期化
scoreboard players set #warp_request st_data 0

# 各プレイヤーへv8説明本を1回だけ配布。v7以前の本を受け取ったプレイヤーにも更新版を再配布。
execute as @a unless score @s st_book matches 2.. run function stalker:book/give

# スタン終了処理を先に行い、その後で残りtickを1減らす
execute if score #stun_ticks st_data matches 1 run function stalker:stun/end
execute if score #stun_ticks st_data matches 1.. run scoreboard players remove #stun_ticks st_data 1

# 各種クールダウン
execute if score #warp_cd st_data matches 1.. run scoreboard players remove #warp_cd st_data 1
execute if score #spawn_retry st_data matches 1.. run scoreboard players remove #spawn_retry st_data 1
execute if score #recovery_retry st_data matches 1.. run scoreboard players remove #recovery_retry st_data 1

# 初回出現タイマー。観戦者以外のプレイヤーがいる間だけ進む
execute if score #spawned st_data matches 0 if entity @a[gamemode=!spectator] run scoreboard players add #spawn_timer st_data 1
execute if score #spawned st_data matches 0 if score #spawn_retry st_data matches 0 if score #spawn_timer st_data >= #spawn_delay st_cfg if entity @a[gamemode=!spectator] as @a[gamemode=!spectator,limit=1,sort=arbitrary] at @s run function stalker:spawn/initial

# 旧世代のストーカーが読み込まれた場合は消す
# v1-v3の旧ピリジャーが遅れてロードされた場合は即除去する。
execute in minecraft:overworld run kill @e[type=minecraft:pillager,tag=st_stalker]
execute in minecraft:the_nether run kill @e[type=minecraft:pillager,tag=st_stalker]
execute in minecraft:the_end run kill @e[type=minecraft:pillager,tag=st_stalker]

execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] unless score @s st_gen = #generation st_data run kill @s
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] unless score @s st_gen = #generation st_data run kill @s
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] unless score @s st_gen = #generation st_data run kill @s

# 現在のストーカーを処理
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:entity/tick
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:entity/tick
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:entity/tick

# 1秒ごとの軽量メンテナンス
scoreboard players add #clock st_data 1
execute if score #clock st_data matches 20.. run function stalker:maintenance

# 救済ワープ。通常移動ではどうにもならない時だけ実行
execute if score #warp_request st_data matches 1 if score #warp_cd st_data matches 0 if entity @a[gamemode=!spectator] as @a[gamemode=!spectator,limit=1,sort=arbitrary] at @s run function stalker:warp
