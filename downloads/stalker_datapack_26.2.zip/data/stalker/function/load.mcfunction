# ストーカーデータパック v8 / load
# Minecraft Java Edition 26.2 / Data Pack 107.1

scoreboard objectives add st_data dummy
scoreboard objectives add st_cfg dummy
scoreboard objectives add st_hp dummy
scoreboard objectives add st_dmg dummy
scoreboard objectives add st_move dummy
scoreboard objectives add st_attack dummy
scoreboard objectives add st_stuck dummy
scoreboard objectives add st_dim dummy
scoreboard objectives add st_y dummy
scoreboard objectives add st_gen dummy
scoreboard objectives add st_book dummy

# fake player の値は add 0 で初期化し、/reload では既存値を保持する。
scoreboard players add #life_x10 st_data 0
scoreboard players add #stun_x10 st_data 0
scoreboard players add #stun_ticks st_data 0
scoreboard players add #spawned st_data 0
scoreboard players add #spawn_timer st_data 0
scoreboard players add #spawn_retry st_data 0
scoreboard players add #generation st_data 0
scoreboard players add #warp_cd st_data 0
scoreboard players add #warp_request st_data 0
scoreboard players add #clock st_data 0
scoreboard players add #missing_ticks st_data 0
scoreboard players add #recovery_retry st_data 0
scoreboard players add #count st_data 0
scoreboard players add #last_dim st_data 0
scoreboard players add #missing_limit st_data 0
scoreboard players add #placed st_data 0
scoreboard players add #life_display st_data 0
scoreboard players add #stun_display st_data 0
scoreboard players add #stun_seconds st_data 0
scoreboard players add #threshold_display st_data 0
scoreboard players add #pack_version st_data 0
scoreboard players add #debug_hp st_data 0
scoreboard players add #debug_max st_data 0

function stalker:config

# 旧「ピレジャーストーカー」v1-v5の記録・個体を可能な限り引き継ぐ。
function stalker:migration/legacy

# 現行の一時マーカーを掃除。
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=st_warp_dest]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=st_warp_dest]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=st_warp_dest]
scoreboard players set #pack_version st_data 8
