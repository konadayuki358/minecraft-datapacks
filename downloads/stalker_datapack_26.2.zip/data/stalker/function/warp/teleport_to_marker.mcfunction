# =============================================
# 同じストーカー個体を生きたままワープさせる。
# kill / 再召喚は一切しない。
# =============================================
# ターゲットがオーバーワールドの場合
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:overworld at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:overworld at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:overworld at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~

# ターゲットがネザーの場合
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:the_nether at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:the_nether at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:the_nether at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~

# ターゲットがエンドの場合
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:the_end at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:the_end at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=arbitrary] if score @s st_gen = #generation st_data in minecraft:the_end at @e[type=minecraft:marker,tag=st_warp_dest,limit=1] run tp @s ~ ~ ~

# ワープ後の勢い・ディメンション待機値をリセット。
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run data modify entity @s Motion set value [0.0d,0.0d,0.0d]
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run data modify entity @s Motion set value [0.0d,0.0d,0.0d]
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run data modify entity @s Motion set value [0.0d,0.0d,0.0d]
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players set @s st_dim 0
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players set @s st_dim 0
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players set @s st_dim 0
