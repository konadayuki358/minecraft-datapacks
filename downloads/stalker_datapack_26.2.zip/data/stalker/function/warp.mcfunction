# =============================================
# v7 救済ワープ
# ストーカー本人を殺さず、同じ個体をそのまま移動させる。
# 実行者は対象プレイヤー。
# =============================================

# 前回の一時マーカーが万一残っていたら掃除。
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=st_warp_dest]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=st_warp_dest]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=st_warp_dest]

scoreboard players set #placed st_data 0
function stalker:warp/search_near

# 安全地点が見つかった場合のみ、同じストーカー個体をテレポート。
execute if score #placed st_data matches 1 run function stalker:warp/teleport_to_marker
execute if score #placed st_data matches 1 run scoreboard players set #warp_cd st_data 200
execute if score #placed st_data matches 1 run scoreboard players set #missing_ticks st_data 0
execute if score #placed st_data matches 1 run tellraw @a {text:'ストーカーがワープしました。',color:'gray'}

# 一時マーカーを削除。
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=st_warp_dest]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=st_warp_dest]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=st_warp_dest]

# 安全地点が無ければ何もせず、2秒後から再試行可能。
execute if score #placed st_data matches 0 run scoreboard players set #warp_cd st_data 40
