execute unless score #done one_chest_setup matches 1 run setblock 0 64 0 minecraft:chest
execute unless score #done one_chest_setup matches 1 run item replace block 0 64 0 container.0 with minecraft:grass_block 16
execute unless score #done one_chest_setup matches 1 run item replace block 0 64 0 container.1 with minecraft:oak_sapling 1
execute unless score #done one_chest_setup matches 1 run item replace block 0 64 0 container.2 with minecraft:ice 1
execute unless score #done one_chest_setup matches 1 run item replace block 0 64 0 container.3 with minecraft:lava_bucket 1
execute unless score #done one_chest_setup matches 1 run item replace block 0 64 0 container.4 with minecraft:end_portal_frame 12
execute unless score #done one_chest_setup matches 1 run setworldspawn 0 65 0
execute unless score #done one_chest_setup matches 1 run spawnpoint @a 0 65 0
execute unless score #done one_chest_setup matches 1 run tp @a 0.5 65 0.5
execute unless score #done one_chest_setup matches 1 run scoreboard players set #done one_chest_setup 1