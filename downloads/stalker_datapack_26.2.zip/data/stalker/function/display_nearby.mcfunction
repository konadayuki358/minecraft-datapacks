# 近距離だけアクションバーに表示
scoreboard players operation #life_display st_data = #life_x10 st_data
scoreboard players operation #life_display st_data /= #ten st_cfg
scoreboard players operation #stun_display st_data = #stun_x10 st_data
scoreboard players operation #stun_display st_data /= #ten st_cfg

execute if entity @a[gamemode=!spectator,distance=..48] run title @a[gamemode=!spectator,distance=..48] actionbar [{text:'ストーカー',color:'dark_red',bold:true},{text:'  累計被ダメージ: ',color:'gray'},{score:{name:'#life_display',objective:'st_data'}},{text:'  |  スタン蓄積: ',color:'gray'},{score:{name:'#stun_display',objective:'st_data'}},{text:'/',color:'dark_gray'},{score:{name:'#threshold_display',objective:'st_data'}}]
