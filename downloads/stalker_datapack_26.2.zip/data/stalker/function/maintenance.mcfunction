# 1秒ごとのメンテナンス
scoreboard players set #clock st_data 0
scoreboard players set #count st_data 0

# 現在ロードされている「現世代」のストーカー数を数える
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players add #count st_data 1
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players add #count st_data 1
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players add #count st_data 1

# 個体ごとのワープ判定
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:entity/maintenance
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:entity/maintenance
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:entity/maintenance

# 現在いるディメンションを記録する。個体がアンロードされた後の復旧判定に使う。
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players set #last_dim st_data 0
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players set #last_dim st_data 1
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run scoreboard players set #last_dim st_data 2

# 1体なら正常
execute if score #count st_data matches 1 run scoreboard players set #missing_ticks st_data 0
execute if score #count st_data matches 1 run scoreboard players set #spawned st_data 1

# 2体以上ロードされていたら、近くに1体だけ作り直す
# 2体以上は通常起きない。ワープ処理では個体を作り直さないため、ここでは自動ワープさせない。
# 世代管理により旧世代はtick側で除去される。

# 出現済みなのにロード中の個体が見つからない場合の待ち時間。
# 同じディメンションにプレイヤーがいる場合も、消滅・アンロード等として約20秒待つ。
# プレイヤーが別ディメンションへ移ったなら、約10秒で追従復旧する。
scoreboard players operation #missing_limit st_data = #unloaded_grace st_cfg
execute if score #last_dim st_data matches 0 in minecraft:overworld unless entity @a[gamemode=!spectator] run scoreboard players operation #missing_limit st_data = #dimension_grace st_cfg
execute if score #last_dim st_data matches 1 in minecraft:the_nether unless entity @a[gamemode=!spectator] run scoreboard players operation #missing_limit st_data = #dimension_grace st_cfg
execute if score #last_dim st_data matches 2 in minecraft:the_end unless entity @a[gamemode=!spectator] run scoreboard players operation #missing_limit st_data = #dimension_grace st_cfg

execute if score #spawned st_data matches 1 if score #count st_data matches 0 run scoreboard players add #missing_ticks st_data 20

# 待ち時間を超えたら、プレイヤーから少し離れた安全候補へ再生成（/kill 後も約20秒）
execute if score #spawned st_data matches 1 if score #count st_data matches 0 if score #missing_ticks st_data >= #missing_limit st_data if score #recovery_retry st_data matches 0 if entity @a[gamemode=!spectator] as @a[gamemode=!spectator,limit=1,sort=arbitrary] at @s run function stalker:recovery

# 近くにいる時だけ、1秒ごとにアクションバー表示
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:display_nearby
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:display_nearby
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run function stalker:display_nearby
