# スタン終了 v6
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run data merge entity @s {NoAI:0b,NoGravity:0b}
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run data merge entity @s {NoAI:0b,NoGravity:0b}
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run data merge entity @s {NoAI:0b,NoGravity:0b}

execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run attribute @s minecraft:knockback_resistance base set 0.25
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run attribute @s minecraft:knockback_resistance base set 0.25
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data run attribute @s minecraft:knockback_resistance base set 0.25

execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run playsound minecraft:block.iron_door.open hostile @a[distance=..32] ~ ~ ~ 0.45 0.75
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run playsound minecraft:block.iron_door.open hostile @a[distance=..32] ~ ~ ~ 0.45 0.75
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker] if score @s st_gen = #generation st_data at @s run playsound minecraft:block.iron_door.open hostile @a[distance=..32] ~ ~ ~ 0.45 0.75
