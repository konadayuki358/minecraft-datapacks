# デバッグ確認用。プレイヤーと同じディメンションにいるストーカーを確認する。
scoreboard players set #debug_hp st_data -1
scoreboard players set #debug_max st_data -1
execute as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=nearest] store result score #debug_hp st_data run data get entity @s Health 10
execute as @e[type=minecraft:vindicator,tag=st_stalker,limit=1,sort=nearest] store result score #debug_max st_data run attribute @s minecraft:max_health get 10
tellraw @s [{text:'[Stalker Debug] ',color:'aqua'},{text:'現在HP(x10)=',color:'gray'},{score:{name:'#debug_hp',objective:'st_data'}},{text:' / 最大HP(x10)=',color:'gray'},{score:{name:'#debug_max',objective:'st_data'}},{text:' / pack v',color:'gray'},{score:{name:'#pack_version',objective:'st_data'}}]
