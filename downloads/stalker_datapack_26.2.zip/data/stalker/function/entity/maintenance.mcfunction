# 1秒ごとの個体メンテナンス v7

# 最大HPとヴィンディケーターAI用属性を再保証。
attribute @s minecraft:max_health base set 1024
attribute @s minecraft:movement_speed base set 0.20
attribute @s minecraft:follow_range base set 128
execute if score #stun_ticks st_data matches 0 run attribute @s minecraft:knockback_resistance base set 0.25

# 通常時はAI・重力を必ず戻す。
execute if score #stun_ticks st_data matches 0 unless data entity @s {NoAI:0b} run data merge entity @s {NoAI:0b}
execute if score #stun_ticks st_data matches 0 unless data entity @s {NoGravity:0b} run data merge entity @s {NoGravity:0b}

# クッキー装備を毎秒再保証。
item replace entity @s weapon.mainhand with minecraft:cookie
item replace entity @s weapon.offhand with air

# 奈落救済
execute store result score @s st_y run data get entity @s Pos[1]
execute if score @s st_y matches ..-80 run scoreboard players set #warp_request st_data 1

# 同じディメンションにプレイヤーがいない時間を計測。
# v4の distance=0.. 判定を廃止し、現在ディメンション内のプレイヤー有無だけを見る。
execute if entity @a[gamemode=!spectator] run scoreboard players set @s st_dim 0
execute unless entity @a[gamemode=!spectator] run scoreboard players add @s st_dim 20
execute if score @s st_dim >= #dimension_grace st_cfg run scoreboard players set #warp_request st_data 1

# 同じディメンションでプレイヤーから約80ブロック（5チャンク相当）以上離れた場合。
# チャンク境界そのものではなく、軽量な実距離判定を使用する。
execute if entity @a[gamemode=!spectator] unless entity @a[gamemode=!spectator,distance=..79.99] run scoreboard players set #warp_request st_data 1
