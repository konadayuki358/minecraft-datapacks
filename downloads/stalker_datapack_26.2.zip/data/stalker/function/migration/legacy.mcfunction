# =============================================
# v1-v5（旧ピレジャーストーカー）からv6への移行
# 旧namespace / tag / scoreboardを新しいstalker系へ引き継ぐ。
# =============================================

# 旧objectiveが無い新規ワールドでも安全に判定できるよう、一時的に作成する。
scoreboard objectives add ps_data dummy
scoreboard objectives add ps_cfg dummy
scoreboard objectives add ps_hp dummy
scoreboard objectives add ps_dmg dummy
scoreboard objectives add ps_move dummy
scoreboard objectives add ps_attack dummy
scoreboard objectives add ps_stuck dummy
scoreboard objectives add ps_dim dummy
scoreboard objectives add ps_y dummy
scoreboard objectives add ps_gen dummy

# 旧データパックを使ったことがある場合だけグローバル記録を移行。
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #life_x10 st_data = #life_x10 ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #stun_x10 st_data = #stun_x10 ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #stun_ticks st_data = #stun_ticks ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #spawned st_data = #spawned ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #spawn_timer st_data = #spawn_timer ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #spawn_retry st_data = #spawn_retry ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #generation st_data = #generation ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #warp_cd st_data = #warp_cd ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #missing_ticks st_data = #missing_ticks ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #recovery_retry st_data = #recovery_retry ps_data
execute if score #pack_version ps_data matches 1.. run scoreboard players operation #last_dim st_data = #last_dim ps_data

# v4-v5のヴィンディケーターを同じ個体のまま新tag / scoreへ移行。
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=ps_stalker] run tag @s add st_stalker
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=ps_stalker] run tag @s add st_stalker
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=ps_stalker] run tag @s add st_stalker
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_gen = @s ps_gen
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_gen = @s ps_gen
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_gen = @s ps_gen
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_hp = @s ps_hp
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_hp = @s ps_hp
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_hp = @s ps_hp
execute in minecraft:overworld as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_dmg = @s ps_dmg
execute in minecraft:the_nether as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_dmg = @s ps_dmg
execute in minecraft:the_end as @e[type=minecraft:vindicator,tag=st_stalker,tag=ps_stalker] run scoreboard players operation @s st_dmg = @s ps_dmg
execute in minecraft:overworld run tag @e[type=minecraft:vindicator,tag=ps_stalker] remove ps_stalker
execute in minecraft:the_nether run tag @e[type=minecraft:vindicator,tag=ps_stalker] remove ps_stalker
execute in minecraft:the_end run tag @e[type=minecraft:vindicator,tag=ps_stalker] remove ps_stalker

# v1-v3の旧ピリジャーが残っていた場合は除去し、ヴィンディケーターの再出現へ回す。
execute in minecraft:overworld if entity @e[type=minecraft:pillager,tag=ps_stalker] run scoreboard players set #spawned st_data 0
execute in minecraft:the_nether if entity @e[type=minecraft:pillager,tag=ps_stalker] run scoreboard players set #spawned st_data 0
execute in minecraft:the_end if entity @e[type=minecraft:pillager,tag=ps_stalker] run scoreboard players set #spawned st_data 0
execute in minecraft:overworld run kill @e[type=minecraft:pillager,tag=ps_stalker]
execute in minecraft:the_nether run kill @e[type=minecraft:pillager,tag=ps_stalker]
execute in minecraft:the_end run kill @e[type=minecraft:pillager,tag=ps_stalker]

# 旧ワープマーカーを掃除。
execute in minecraft:overworld run kill @e[type=minecraft:marker,tag=ps_warp_dest]
execute in minecraft:the_nether run kill @e[type=minecraft:marker,tag=ps_warp_dest]
execute in minecraft:the_end run kill @e[type=minecraft:marker,tag=ps_warp_dest]

# 旧scoreboardを削除し、v6以降はst_*だけを使用する。
scoreboard objectives remove ps_data
scoreboard objectives remove ps_cfg
scoreboard objectives remove ps_hp
scoreboard objectives remove ps_dmg
scoreboard objectives remove ps_move
scoreboard objectives remove ps_attack
scoreboard objectives remove ps_stuck
scoreboard objectives remove ps_dim
scoreboard objectives remove ps_y
scoreboard objectives remove ps_gen
