# 手動テスト用: /function stalker:admin/respawn
# 累計被ダメージ等のグローバル記録は保持する。
execute in minecraft:overworld run kill @e[type=minecraft:vindicator,tag=st_stalker]
execute in minecraft:the_nether run kill @e[type=minecraft:vindicator,tag=st_stalker]
execute in minecraft:the_end run kill @e[type=minecraft:vindicator,tag=st_stalker]
# v1-v3の旧ピリジャーが残っていた場合も掃除する。
execute in minecraft:overworld run kill @e[type=minecraft:pillager,tag=st_stalker]
execute in minecraft:the_nether run kill @e[type=minecraft:pillager,tag=st_stalker]
execute in minecraft:the_end run kill @e[type=minecraft:pillager,tag=st_stalker]
scoreboard players set #spawned st_data 0
scoreboard players operation #spawn_timer st_data = #spawn_delay st_cfg
scoreboard players set #spawn_retry st_data 0
scoreboard players set #missing_ticks st_data 0
scoreboard players set #warp_request st_data 0
scoreboard players set #warp_cd st_data 0
tellraw @s {text:'ストーカーを再生成します。累計被ダメージは保持されます。',color:'gray'}
