execute unless score #done kind_one_chest_setup matches 1 run setblock 0 64 0 minecraft:chest
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.0 with minecraft:grass_block 64
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.1 with minecraft:water_bucket 1
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.2 with minecraft:water_bucket 1
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.3 with minecraft:lava_bucket 1
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.4 with minecraft:pointed_dripstone 1
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.5 with minecraft:dripstone_block 1
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.6 with minecraft:oak_sapling 4
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.7 with minecraft:wheat_seeds 4
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.8 with minecraft:end_portal_frame 12
execute unless score #done kind_one_chest_setup matches 1 run item replace block 0 64 0 container.9 with minecraft:villager_spawn_egg 2
execute unless score #done kind_one_chest_setup matches 1 run setworldspawn 0 65 0
execute unless score #done kind_one_chest_setup matches 1 run spawnpoint @a 0 65 0
execute unless score #done kind_one_chest_setup matches 1 run tp @a 0.5 65 0.5
execute unless score #done kind_one_chest_setup matches 1 run scoreboard players set #done kind_one_chest_setup 1