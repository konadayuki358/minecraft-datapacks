# 新しく生成したストーカー個体の初期化 v6
# ピリジャーを廃止し、ヴィンディケーター本来の近接AI・経路探索を利用する。
# 初期装備の鉄の斧はクッキーへ交換する。
item replace entity @s weapon.mainhand with minecraft:cookie
item replace entity @s weapon.offhand with air

# 通常ヴィンディケーター(移動速度0.35)より遅め。
# follow_rangeを広げ、ロード範囲内ではプレイヤー追跡を継続しやすくする。
attribute @s minecraft:max_health base set 1024
attribute @s minecraft:movement_speed base set 0.20
attribute @s minecraft:follow_range base set 128
attribute @s minecraft:knockback_resistance base set 0.25

data merge entity @s {Health:1024.0f,NoAI:0b,NoGravity:0b,PersistenceRequired:1b,CanPickUpLoot:0b,CanJoinRaid:0b,CustomName:{text:'ストーカー',color:'dark_red',bold:true},CustomNameVisible:1b}

scoreboard players set @s st_hp 10240
scoreboard players set @s st_dmg 0
scoreboard players set @s st_move 0
scoreboard players set @s st_attack 0
scoreboard players set @s st_stuck 0
scoreboard players set @s st_dim 0
scoreboard players set @s st_y 0
scoreboard players operation @s st_gen = #generation st_data

# ワープや再生成がスタン中に起きた場合も状態を引き継ぐ
execute if score #stun_ticks st_data matches 1.. run data merge entity @s {NoAI:1b,NoGravity:1b}
execute if score #stun_ticks st_data matches 1.. run attribute @s minecraft:knockback_resistance base set 1
