# この地点をワープ先として一時マーカー化する。
summon minecraft:marker ~ ~ ~ {Tags:['st_warp_dest']}
scoreboard players set #placed st_data 1
