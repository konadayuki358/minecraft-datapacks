# 初回・復旧用。プレイヤーからおよそ16～24ブロック離れた候補。
# 背後を優先し、正面は最後。
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^-24 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^17 ^ ^-17 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-17 ^ ^-17 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^24 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-24 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^17 ^ ^17 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-17 ^ ^17 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^24 run function stalker:spawn/try_column

# 24ブロック側で見つからない場合の予備候補
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^-16 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^12 ^ ^-12 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-12 ^ ^-12 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^16 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-16 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^12 ^ ^12 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-12 ^ ^12 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^16 run function stalker:spawn/try_column
