# ============================================================
# gold_tool_flattening - tick
# Minecraft Java Edition 26.2
# 毎tick、各プレイヤーのオフハンドだけを判定します。
# メインハンドに持っているだけでは発動しません。
# ============================================================

# 初回のみ説明本を配布
execute as @a[tag=!gtf_manual_v2_given] run function gold_tool_flattening:give_manual

# 金の剣：現在いるディメンションのプレイヤー以外のエンティティを全削除
execute as @a at @s if items entity @s weapon.offhand minecraft:golden_sword run function gold_tool_flattening:gold_sword

# 金の斧：周囲の原木・葉を破壊扱いで除去
execute as @a at @s if items entity @s weapon.offhand minecraft:golden_axe run function gold_tool_flattening:gold_axe

# 金のシャベル：オーバーワールド専用
execute as @a at @s if dimension minecraft:overworld if items entity @s weapon.offhand minecraft:golden_shovel run function gold_tool_flattening:gold_shovel

# 金のクワ：ネザー専用
execute as @a at @s if dimension minecraft:the_nether if items entity @s weapon.offhand minecraft:golden_hoe run function gold_tool_flattening:gold_hoe

# 金のつるはし：エンド専用
# 初期スポーン黒曜石プラットフォーム保護のため、
# X=90..110 / Z=-10..10 の安全地帯では処理そのものを実行しません。
execute as @a at @s if dimension minecraft:the_end if items entity @s weapon.offhand minecraft:golden_pickaxe unless entity @s[x=90,y=-64,z=-10,dx=20,dy=384,dz=20] run function gold_tool_flattening:gold_pickaxe
