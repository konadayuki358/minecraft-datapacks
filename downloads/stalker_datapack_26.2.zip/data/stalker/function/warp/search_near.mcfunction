# 救済ワープ用安全地点探索。
# プレイヤーから約8～10ブロック。背後・斜め後ろを優先。
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^-10 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^7 ^ ^-7 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-7 ^ ^-7 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^10 ^ ^0 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-10 ^ ^0 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^7 ^ ^7 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-7 ^ ^7 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^10 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^-8 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^8 ^ ^0 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-8 ^ ^0 run function stalker:warp/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^8 run function stalker:warp/try_column
