# 救済ワープ用。プレイヤーから約8～10ブロック。
# v1より近すぎる候補を廃止し、ワープ直後の理不尽な接触を防ぐ。
# 背後・斜め後ろを優先し、正面は最後。
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^-10 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^7 ^ ^-7 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-7 ^ ^-7 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^10 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-10 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^7 ^ ^7 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-7 ^ ^7 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^10 run function stalker:spawn/try_column

# 10ブロック側で安全地点が無い場合のみ8ブロック候補
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^-8 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^8 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^-8 ^ ^0 run function stalker:spawn/try_column
execute if score #placed st_data matches 0 rotated ~ 0 positioned ^ ^ ^8 run function stalker:spawn/try_column
