# スタン開始
scoreboard players operation #stun_ticks st_data = #stun_duration st_cfg
scoreboard players set #stun_x10 st_data 0

data merge entity @s {NoAI:1b,NoGravity:1b,Motion:[0.0d,0.0d,0.0d]}
attribute @s minecraft:knockback_resistance base set 1

particle minecraft:electric_spark ~ ~1 ~ 0.45 0.8 0.45 0.05 24 force @a[distance=..64]
playsound minecraft:block.anvil.land hostile @a[distance=..48] ~ ~ ~ 0.55 1.8
title @a[gamemode=!spectator,distance=..48] actionbar {text:'ストーカーはスタンした！',color:'yellow',bold:true}
