# ============================================================
# 初回説明本の配布
# プレイヤータグ gtf_manual_v2_given が無いプレイヤーに1回だけ実行されます。
#
# メインハンドが空なら、本を直接メインハンドへ入れます。
# 既に何か持っている場合は、大切なアイテムを上書きせずインベントリへ入れます。
# ============================================================

# メインハンドにアイテムがある場合：インベントリへ配布
execute if items entity @s weapon.mainhand * run loot give @s loot gold_tool_flattening:manual

# メインハンドが空の場合：そのまま手に持たせる
execute unless items entity @s weapon.mainhand * run loot replace entity @s weapon.mainhand 1 loot gold_tool_flattening:manual

# 二重配布防止
tag @s add gtf_manual_v2_given

# 配布メッセージ
tellraw @s {text:"[gold_tool_flattening] 修正版の金ツール整地マニュアルを配布しました。",color:"gold"}
