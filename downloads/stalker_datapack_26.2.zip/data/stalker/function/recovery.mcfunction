# 消滅・チャンクアンロード等からの復旧
# 即座に目の前へ出さず、初回出現と同じく少し離れた候補へ再生成する。
scoreboard players set #placed st_data 0
function stalker:spawn/search_far

execute if score #placed st_data matches 1 run scoreboard players set #missing_ticks st_data 0
execute if score #placed st_data matches 1 run scoreboard players set #recovery_retry st_data 0
execute if score #placed st_data matches 1 run tellraw @a {text:'ストーカーが再び現れました。',color:'gray'}
execute if score #placed st_data matches 0 run scoreboard players set #recovery_retry st_data 40
