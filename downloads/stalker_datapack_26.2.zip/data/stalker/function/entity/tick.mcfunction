# ストーカー1体分の毎tick処理 v7
function stalker:entity/damage

# スタン中だけAIを完全停止。
execute if score #stun_ticks st_data matches 1.. run function stalker:entity/frozen

# 通常時の移動・攻撃はヴィンディケーター本来のAIへ任せる。
# コマンドtp移動・追加damage攻撃は行わない。
