# ==============================
# ストーカーデータパック v8 調整用設定
# ==============================
# 被ダメージは 0.1 HP 単位（x10）で内部管理する。

# 最大HP 1024.0
scoreboard players set #max_hp_x10 st_cfg 10240

# 100.0 ダメージ蓄積でスタン
scoreboard players set #stun_threshold_x10 st_cfg 1000

# スタン時間 100tick = 5秒
scoreboard players set #stun_duration st_cfg 100

# 初回出現まで 7000tick = 約5分50秒
scoreboard players set #spawn_delay st_cfg 7000

# 別ディメンションへ逃げた場合の追従猶予 200tick = 10秒
scoreboard players set #dimension_grace st_cfg 200

# 追跡不能状態が続いた場合の救済ワープ判定 1800tick = 約90秒
# v1より長くして、不必要なワープを減らす。
scoreboard players set #stuck_limit st_cfg 1800

# ストーカーが消滅・アンロード等で見つからない場合の復旧待ち 400tick = 約20秒
# /kill などで消滅した場合も、この待ち時間の後に復活する。
scoreboard players set #unloaded_grace st_cfg 400

# 計算用定数
scoreboard players set #ten st_cfg 10
scoreboard players set #twenty st_cfg 20

# 表示用
scoreboard players operation #threshold_display st_data = #stun_threshold_x10 st_cfg
scoreboard players operation #threshold_display st_data /= #ten st_cfg

# v8メモ:
# 救済ワープ時も個体をkill/再召喚せず、同じストーカーを生きたままtpする。
# 同一ディメンションでは約80ブロック（5チャンク相当）離れると救済ワープする。
