# 安全候補へ新しいストーカーを生成 v6
# 本体はヴィンディケーター。鉄の斧はinitでクッキーへ即交換する。
# 移動・近接攻撃はヴィンディケーター本来のAIを使用する。
summon minecraft:vindicator ~ ~ ~ {Tags:['st_stalker','st_new'],CustomName:{text:'ストーカー',color:'dark_red',bold:true},CustomNameVisible:1b,PersistenceRequired:1b,CanPickUpLoot:0b,CanJoinRaid:0b,Health:1024.0f,attributes:[{id:'minecraft:max_health',base:1024.0d},{id:'minecraft:movement_speed',base:0.20d},{id:'minecraft:follow_range',base:128.0d},{id:'minecraft:knockback_resistance',base:0.25d}]}

execute if entity @e[type=minecraft:vindicator,tag=st_new,distance=..1.5,limit=1,sort=nearest] run scoreboard players add #generation st_data 1
execute as @e[type=minecraft:vindicator,tag=st_new,distance=..1.5,limit=1,sort=nearest] run function stalker:entity/init
execute if entity @e[type=minecraft:vindicator,tag=st_new,distance=..1.5,limit=1,sort=nearest] run scoreboard players set #placed st_data 1
tag @e[type=minecraft:vindicator,tag=st_new,distance=..1.5] remove st_new
