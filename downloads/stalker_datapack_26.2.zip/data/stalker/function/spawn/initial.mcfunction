# 初回出現。プレイヤーから16～24ブロックほど離れた候補を探す。
scoreboard players set #placed st_data 0
function stalker:spawn/search_far

execute if score #placed st_data matches 1 run scoreboard players set #spawned st_data 1
execute if score #placed st_data matches 1 run scoreboard players set #missing_ticks st_data 0
execute if score #placed st_data matches 1 run scoreboard players set #spawn_retry st_data 0
execute if score #placed st_data matches 1 run tellraw @a {text:'どこかで「ストーカー」が動き始めた。',color:'dark_red'}
execute if score #placed st_data matches 0 run scoreboard players set #spawn_retry st_data 40
