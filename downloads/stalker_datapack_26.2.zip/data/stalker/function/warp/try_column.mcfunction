# 候補XZの上下6ブロックから安全地点を探す。
execute if score #placed st_data matches 0 positioned ~ ~ ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~1 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~-1 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~2 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~-2 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~3 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~-3 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~4 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~-4 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~5 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~-5 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~6 ~ run function stalker:warp/try_here
execute if score #placed st_data matches 0 positioned ~ ~-6 ~ run function stalker:warp/try_here
